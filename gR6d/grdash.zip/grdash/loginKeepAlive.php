<?php 
session_start();
echo 'Session is active';
?>
