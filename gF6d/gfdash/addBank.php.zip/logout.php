<?php 
session_start();
session_unset();
session_destroy();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Logout</title>
</head>
<body>
<script>
        localStorage.removeItem("username");
        localStorage.removeItem("role");
        localStorage.removeItem("activeMainMenu");
        localStorage.setItem('sessionActive', 'false');
        setTimeout(function() {
            window.location.href = 'index.php';
        }, 100);
      </script>
    <script src="../assets/js/session_check.js"></script>
</body>
</html>
